import org.junit.*;

public class TClass {
    InterF functcall;
    @Before
    public void initlize(){
        functcall = new functionsss() ;
        System.out.println("Before");
    }
    @After
    public void Afterech(){
        System.out.println("After");
    }
    @Test
    public void PrimeTest(){
        int num = 33;
        Boolean r = functcall.isPrime(num);
        boolean e = true;
        Assert.assertSame(e,r);
    }
    @Test
    public void EvenOddTest(){
        int num = 12;
        Boolean r = functcall.isEvenOdd(num);
        boolean e = true;
        Assert.assertSame(e,r);
    }
    @Test
    public void avgTest(){
        int[] array = {4, 12, 24, 36};
        int r = functcall.arrayAvg(array);
        int e = 19;
        Assert.assertSame(e,r);
    }
    @Test
    public void palindromeTest(){
        String str = "abccba";
        Boolean r = functcall.isPalindrome(str);
        boolean e = true;
        Assert.assertSame(e,r);
    }
    @Test
    public void celToFarTest(){
        int num =37;
        int r = Math.round(functcall.celToFar(num));
        int e = Math.round(98.6);
        Assert.assertSame(e,r);
    }
    @Test
    public void celToKelTest(){
        int num = 30;
        int r = Math.round(functcall.celToKel(num));
        int  e = Math.round(303.15);
        Assert.assertSame(e,r);
    }
}