

public class Funct implements InterF {
    //Prime Number program where user inputs an integer and program detect whether it is a prime number, or it is not.
    public  Boolean isPrime(Integer num){
        int mid = 0;
        int diss = 0;
        boolean result = false;
        mid = num/2;
        if((num == 0) || (num == 1)){
            result = false;
        }else{
            for(int i = 2;i <= mid;i++){
                if(num%i == 0){
                    diss = 1;
                    result = false;
                    break;
                }
            }
            if(diss == 0)  {
                return result = true;
            }
        }
        return result;
    }
    //Even off program where user inputs an integer and program detect whether it is an even or an odd number.
    public  boolean isEvenOdd(Integer num){
        boolean result = false;
        if(num % 2 == 0){
            result = true;
        }
        else{
            result = false;
        }
        return result;
    }
    //User adds integers in an array and the program can calculate the average of the integers.
    public int arrayAvg(int[] arry){
            double sum = 0;
            for(int i=0; i < arry.length; i++){
                sum = sum + arry[i];
            }
            double avg = sum / arry.length;
            return (int) avg;
        }
    //User inputs two string values and program checks if they are palindrome strings or not.
    public boolean isPalindrome(String str) {
        int i = 0, j = str.length() - 1;
        while (i < j) {
            if (str.charAt(i) != str.charAt(j))
                return false;
            i++;
            j--;
        }
        return true;
    }
    //Celsius converts them to Fahrenheit
    public double celToFar(double num) {
        Double F = num * (9 / 5) + 32;
        return F;
    }
    //User inputs temperature in Celsius and program converts them to Fahrenheit and Kelvin scale.
    public double celtoKel(double num) {
        float K = (float) (num + 273.15);
        return K;
    }
}