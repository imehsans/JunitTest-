

public interface InterF{
	public  abstract Boolean isPrime(Integer num);
	public abstract boolean isEvenOdd(Integer num);
	public  abstract int arrayAvg(int[] arry);
	public  abstract boolean isPalindrome(String str);
	public abstract double celToFar(double num);
	public abstract double celToKel(double num);
}